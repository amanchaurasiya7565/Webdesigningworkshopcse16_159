package com.aman.employee.bank;

public class SavingsAccount extends BankAccount {

    private static final double INTEREST_RATE = 0.05;

    public SavingsAccount(int accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }

    @Override
    public double calculateInterest() {
        return getBalance() * INTEREST_RATE;
    }
}

# Employee Management Spring Boot Project

This project implements the PDF experiments using Java 17 and Spring Boot under the package root `com.aman.employee`.

## File Structure

```text
src/main/java/com/aman/employee
├── EmployeeApiApplication.java
├── bank
│   ├── BankAccount.java
│   ├── BankDemo.java
│   ├── CurrentAccount.java
│   └── SavingsAccount.java
├── controller
│   └── EmployeeController.java
├── entity
│   └── Employee.java
├── repository
│   └── EmployeeRepository.java
├── service
│   └── EmployeeService.java
└── student
    ├── Student.java
    └── StudentController.java
```

## Run

```bash
mvn spring-boot:run
```

The application starts at:

```text
http://localhost:8080
```

## Student REST API

```http
GET /
GET /student
POST /student
```

Sample student body:

```json
{
  "id": 1,
  "name": "Aman",
  "course": "Web Development"
}
```

## Employee CRUD API

```http
POST /employees
GET /employees
GET /employees/{id}
PUT /employees/{id}
DELETE /employees/{id}
```

Sample employee body:

```json
{
  "name": "Pranshi Verma",
  "department": "IT",
  "salary": 50000
}
```

## H2 Database Console

```text
http://localhost:8080/h2-console
```

JDBC URL:

```text
jdbc:h2:mem:employee_db
```

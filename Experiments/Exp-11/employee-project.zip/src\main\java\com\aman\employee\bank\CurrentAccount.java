package com.aman.employee.bank;

public class CurrentAccount extends BankAccount {

    private static final double INTEREST_RATE = 0.02;

    public CurrentAccount(int accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }

    @Override
    public double calculateInterest() {
        return getBalance() * INTEREST_RATE;
    }
}

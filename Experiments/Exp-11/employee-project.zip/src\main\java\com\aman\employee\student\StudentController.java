package com.aman.employee.student;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

    private Student student;

    @GetMapping("/")
    public String welcomeMessage() {
        return "Welcome to Student Management REST API";
    }

    @GetMapping("/student")
    public ResponseEntity<Student> getStudent() {
        if (student == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(student);
    }

    @PostMapping("/student")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        this.student = student;
        return ResponseEntity.status(HttpStatus.CREATED).body(student);
    }
}

package com.aman.employee.bank;

public class BankDemo {

    public static void main(String[] args) {
        SavingsAccount savingsAccount = new SavingsAccount(101, "Rahul", 10000);
        CurrentAccount currentAccount = new CurrentAccount(102, "Anita", 20000);

        savingsAccount.deposit(2000);
        currentAccount.deposit(3000);

        printAccount("Savings Account", savingsAccount);
        printAccount("Current Account", currentAccount);
    }

    private static void printAccount(String title, BankAccount account) {
        System.out.println("----- " + title + " -----");
        System.out.println("Account Number: " + account.getAccountNumber());
        System.out.println("Account Holder Name: " + account.getAccountHolderName());
        System.out.println("Balance: " + account.getBalance());
        System.out.println("Interest: " + account.calculateInterest());
        System.out.println();
    }
}
